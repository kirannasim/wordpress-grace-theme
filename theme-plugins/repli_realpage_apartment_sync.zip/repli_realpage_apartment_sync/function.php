<?php
global $rrac_version;
global $update_available_version;
$rrac_version = RRAC_PLUGIN_VERSION;
global $ajax_url; 
$ajax_url = admin_url('admin-ajax.php');
include_once('realpage_api.php');
/**************Install Functions ***************/
function rrac_install() {
	global $wpdb;
	global $rrac_version;

  /////Tab Group Table
  $table_name_group = $wpdb->prefix . 'rrac_floorplan_group';
  
  $charset_collate = $wpdb->get_charset_collate();

  $sql_group = "CREATE TABLE IF NOT EXISTS $table_name_group (
    id mediumint(9) NOT NULL AUTO_INCREMENT,
    group_name varchar(255) DEFAULT '',
    bedroom varchar(255) DEFAULT '',
    description text,
    status mediumint(2) NOT NULL DEFAULT 1,
    order_no mediumint(2) NOT NULL DEFAULT 0,
    time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY  (id)
  ) $charset_collate;";

  require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
  dbDelta( $sql_group );


	$table_name_marketing_type = $wpdb->prefix . 'rrac_floorplan_marketing_type';
	
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE IF NOT EXISTS $table_name_marketing_type (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		api_response_id mediumint(9) NOT NULL ,
		marketing_type tinytext NOT NULL,
		tagline varchar(55) DEFAULT '',
		floorplan_code varchar(55) DEFAULT '',
		bedroom varchar(55) DEFAULT '',
		bathroom varchar(55) DEFAULT '',
		size varchar(55) DEFAULT '',
		min_rent varchar(55) DEFAULT '',
		max_rent varchar(55) DEFAULT '',
		deposit varchar(55) DEFAULT '',
		term_range varchar(55) DEFAULT '',
		description text,
		image varchar(255) DEFAULT '',
    status mediumint(2) NOT NULL DEFAULT 1,
    order_no mediumint(2) NOT NULL DEFAULT 0,
		time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );

  
  try{
      //////Add Floorplan Group field on rrac_floorplan_marketing_type table
      $sql_alter_table = "ALTER TABLE $table_name_marketing_type ADD COLUMN `floorplan_group_id` mediumint(11) DEFAULT NULL AFTER `marketing_type`";
      $wpdb->query( $sql_alter_table );
      //////Add image_gallery field on rrac_floorplan_marketing_type table
      $sql_alter_table = "ALTER TABLE $table_name_marketing_type ADD COLUMN `image_gallery` text DEFAULT NULL AFTER `image`";
     $wpdb->query( $sql_alter_table );
     //////Add vertual_tour field on rrac_floorplan_marketing_type table
     $sql_alter_table = "ALTER TABLE $table_name_marketing_type ADD COLUMN  `virtual_tour` text DEFAULT NULL AFTER `image_gallery`";
     $wpdb->query( $sql_alter_table );
  }
  catch(Exception $e){

  }
   

	add_option( 'rrac_version', $rrac_version );
  // $appTypeArray = array(
  //                         'A'=>'1 Bedroom' ,
  //                         'B'=>'2 Bedroom' ,
  //                         'C'=>'3 Bedroom' ,
  //                         'S'=>'Studio' 
  //                       );
  // add_option('rrac_tab_heading',json_encode($appTypeArray));
  add_option('rrac_contact_email',get_option('admin_email'));
	rrac_default_color_dataset();
}

/**************Install Functions ***************/



/************** Add Menu ***************/

add_action('admin_menu', 'rrac_plugin_setup_menu');
function rrac_plugin_setup_menu(){

$update_notification = '';
if(get_option('rrac_update_status') == 1){
  $update_notification = '<span class="awaiting-mod">1</span>';
}


add_menu_page( 'REPLI ApartmentSync', 'REPLI ApartmentSync '.$update_notification, 'manage_options', 'rrac_config', 'rrac_config' ,plugin_dir_url(__FILE__).'assets/images/plugin_logo.png');
    add_submenu_page( 'rrac_config', 'Configuration', 'Configuration', 'manage_options', 'rrac_config', 'rrac_config' );
    add_submenu_page( 'rrac_config', 'Floor Plan Group', 'Floor Plan Group', 'manage_options', 'rrac_floorplan_group', 'rrac_floorplan_group_func' );
    add_submenu_page( '', 'Floor Plan Group Edit', 'Floor Plan Group Edit', 'manage_options', 'rrac_floorplan_group_edit', 'rrac_floorplan_group_edit_func' );
    add_submenu_page( 'rrac_config', 'Floor Plan Type', 'Floor Plan Type', 'manage_options', 'floor_plan_type', 'floor_plan_type_func' );
    add_submenu_page( '', 'Floor Plan Type Edit', 'Floor Plan Type Edit', 'manage_options', 'floor_plan_type_edit', 'floor_plan_type_edit_func' );
    add_submenu_page( '', 'Available Unit List', 'Available Unit List', 'manage_options', 'available_unit_list', 'available_unit_list_func' );
    //add_submenu_page( 'rrac_config', 'Tab Heading', 'Tab Heading', 'manage_options', 'tab_heading', 'tab_heading_func' );
    add_submenu_page( 'rrac_config', 'Tab Sorting', 'Tab Sorting', 'manage_options', 'tab_sorting', 'tab_sorting_func' );
    add_submenu_page( 'rrac_config', 'Check For Update', 'Check For Update'.$update_notification, 'manage_options', 'check_update', 'check_update_func' );

}

 
function rrac_config(){
  include_once('admin/rrac_config.php');
}
function rrac_floorplan_group_func(){
  include_once('admin/rrac_floorplan_group.php');
}
function rrac_floorplan_group_edit_func(){
  include_once('admin/floorplan_group_addedit.php');
}
function floor_plan_type_func()
{
	include_once('admin/floor_plan_type.php');
}
function floor_plan_type_edit_func()
{
	include_once('admin/floor_plan_type_edit.php');
}
function available_unit_list_func()
{
  include_once('admin/available_unit_list.php');
}
function tab_heading_func()
{
  include_once('admin/tab_heading.php');
}
function tab_sorting_func()
{
  include_once('admin/tab_sorting.php');
}
function check_update_func()
{
  include_once('admin/check_update.php');
}

/************** Add Menu ***************/

/************** Add Configuration into database ***************/
add_action( 'wp_ajax_rrac_configuration_add', 'rrac_configuration_add' );
//add_action( 'wp_ajax_nopriv_rrac_configuration_add', 'rrac_configuration_add' );
function rrac_configuration_add(){

    global $wpdb;
   	unset($_POST['action']);
   	unset($_POST['Save']);
   	foreach($_POST as $key=>$value)
   	{
   		update_option($key , $value);
   	}
   	echo 1;
    exit();
}
/************** Add Configuration into database ***************/

/************** syncApartment into database ***************/
add_action( 'wp_ajax_rrac_syncApartment', 'rrac_syncApartment' );
//add_action( 'wp_ajax_nopriv_rrac_configuration_add', 'rrac_configuration_add' );
function rrac_syncApartment(){

    $first_load_data = false;

    global $wpdb;
    $table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
    $results = array();
   	$all_options = wp_load_alloptions();
   	if( 
   		isset($all_options['realpage_api_user']) && $all_options['realpage_api_user'] !='' &&
   		isset($all_options['realpage_api_password']) && $all_options['realpage_api_password'] !='' &&
   		isset($all_options['realpage_api_siteid']) && $all_options['realpage_api_siteid'] !='' &&
   		isset($all_options['realpage_api_pmcid']) && $all_options['realpage_api_pmcid'] !='' )
   	{
   		$parser = getpicklists('LIST_FLOORPLANIDANDNAME');
		
  		if(isset($parser->GetPickListsResponse->GetPickListsResult->PickListObject->Contents->PicklistItem))
  		{
        $arrayGroup = array();
        $table_name_group = $wpdb->prefix . 'rrac_floorplan_group';
        $sql_search_group = "select * from $table_name_group where 1";
        $search_res_group = $wpdb->get_results($sql_search_group);
        foreach($search_res_group as $search_res_grp)
        {
            $arrayGroup[$search_res_grp->id] = $search_res_grp->bedroom;
        }

  			$total_record = count($parser->GetPickListsResponse->GetPickListsResult->PickListObject->Contents->PicklistItem);
  			$res = $parser->GetPickListsResponse->GetPickListsResult->PickListObject->Contents->PicklistItem;
  			//////status 0 all record
  			$sql_update_status = "UPDATE $table_name SET
  					status = 0 
  					WHERE 1;
  					";
  			$wpdb->query($sql_update_status);
  			$new_entry = 0;
  			for($i=0; $i<$total_record; $i++)
  			{
  				$floorplan_det = floorplan_list_by_id($res[$i]->Value);
  				$floorplancode = '';
  				$bedrooms = '';
  				$bathrooms = '';
  				$size = '';
  				$min_rent = '';
  				$max_rent = '';
          $floorplan_group_id = NULL;

  				if(isset($floorplan_det->ListResponse->ListResult->FloorPlanObject))
  				{
  					$floorplancode = $floorplan_det->ListResponse->ListResult->FloorPlanObject->FloorPlanCode;
  					$bedrooms = $floorplan_det->ListResponse->ListResult->FloorPlanObject->Bedrooms;
  					$bathrooms = $floorplan_det->ListResponse->ListResult->FloorPlanObject->Bathrooms;
  					$size = $floorplan_det->ListResponse->ListResult->FloorPlanObject->RentableSquareFootage;
  					$min_rent = $floorplan_det->ListResponse->ListResult->FloorPlanObject->RentMin;
  					$max_rent = $floorplan_det->ListResponse->ListResult->FloorPlanObject->RentMax;
            /////////
            $key = array_search($bedrooms, $arrayGroup);
            if ($key !== false) {
              $floorplan_group_id = $key;
            }
  				}

  				$sql_search = "select * from $table_name where api_response_id = ".$res[$i]->Value;
          
  				
          $search_res = $wpdb->get_results($sql_search);
  				if(empty($search_res))
  				{
  					
  					$sql = "INSERT INTO $table_name SET
  					api_response_id = '".$res[$i]->Value."',
  					marketing_type = '".$res[$i]->Text."',
  					floorplan_code = '".$floorplancode."',
            floorplan_group_id = '".$floorplan_group_id."',
  					bedroom = '".$bedrooms."',
  					bathroom = '".$bathrooms."',
  					size = '".$size."',
  					min_rent = '".$min_rent."',
  					max_rent = '".$max_rent."'
  					;
  					";
            $first_load_data[$i]['status'] = 0 ;
  					$new_entry++;
  				}
  				else
  				{
  					$sql = "UPDATE $table_name SET
  					status = 1 ,
  					floorplan_code = '".$floorplancode."',
  					bedroom = '".$bedrooms."',
  					bathroom = '".$bathrooms."',
  					size = '".$size."',
  					min_rent = '".$min_rent."',
  					max_rent = '".$max_rent."'
  					WHERE 
  					api_response_id = '".$res[$i]->Value."';
  					";
            $first_load_data[$i]['status'] = 1 ;
  				}
  				$wpdb->query($sql);
          $api_response_result = "select `api_response_id` from $table_name where api_response_id = ".$res[$i]->Value;
          $api_response_result_array  = $wpdb->get_row($api_response_result);

          $first_load_data[$i]['floorplan_id'] =  $api_response_result_array->api_response_id;



          $max_day = get_option('calendar_upcoming_days'); ////to get max date
          
          $first_load_data[$i]['moveindate'] = date('Y-m-d', strtotime("+".$max_day." day", strtotime(date('Y-m-d'))));

          //echo dirname(__FILE__);die();

  				
  			}

        if(is_array($first_load_data)) {
            file_put_contents(dirname(__FILE__).'/first_load_data.json', json_encode($first_load_data));
        }


  			$results['status'] = 1;
     			$results['message'] = $new_entry ." new Apartment fount";
  		}
      else
      {
          $results['status'] = 0;
          $results['message'] = "API return empty.";
      }
		

   	}
   	else
   	{
   		$results['status'] = 0;
   		$results['message'] = "API credential not setup. Please setup first.";

   	}
   	echo json_encode($results);
    exit();
}
/************** syncApartment into database ***************/

/************** Apartment Type Edit ***************/
add_action( 'wp_ajax_rrac_Apartment_type_edit', 'rrac_Apartment_type_edit' );
//add_action( 'wp_ajax_nopriv_rrac_Apartment_type_edit', 'rrac_Apartment_type_edit' );
function rrac_Apartment_type_edit(){

    global $wpdb;
    $table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
   	unset($_POST['action']);
   	unset($_POST['Save']);
    $sql_get_data = "select image_gallery from $table_name where id=".$_POST['idd'];
    $resData = $wpdb->get_row($sql_get_data);
    //////////////Image Gallery
    if($resData->image_gallery != "" && $_POST['image_gallery'] != "")
    {
        $_POST['image_gallery'] = $resData->image_gallery.','.$_POST['image_gallery'];
    }
    if($_POST['image_gallery'] == "")
    {
        $_POST['image_gallery'] = $resData->image_gallery;
    }
    /////////////Vertual Tour
    $vertual_tour_iframe = null;
    if(isset($_POST['vertual_tour']) && $_POST['vertual_tour'] == 1)
    {
        $vertual_tours = array();
        foreach($_POST['vertual_tour_iframe'] as $vertual_tr)
        {
          if(trim($vertual_tr) != "")
            $vertual_tours[] = trim($vertual_tr);
        }
        $vertual_tour_iframe = json_encode($vertual_tours);
    }

   	$sql = "UPDATE $table_name SET
   			marketing_type = '".$_POST['marketing_type']."',
   			tagline = '".$_POST['tagline']."',
        floorplan_group_id = '".$_POST['floorplan_group_id']."',
   			bedroom = '".$_POST['bedroom']."',
   			bathroom = '".$_POST['bathroom']."',
   			size = '".$_POST['size']."',
   			min_rent = '".$_POST['min_rent']."',
   			max_rent = '".$_POST['max_rent']."',
   			deposit = '".$_POST['deposit']."',
   			term_range = '".$_POST['term_range']."',
			  description = '".$_POST['description']."',
			  image = '".$_POST['image']."',
        image_gallery = '".$_POST['image_gallery']."',
        virtual_tour = '".$vertual_tour_iframe."',
        status = '".$_POST['status']."'
			WHERE 
			id = '".$_POST['idd']."';
			";
			//echo $sql;
	$wpdb->query($sql);
   	echo 1;
    exit();
}
/************** Apartment Type Edit ***************/


/************** Apartment Details ***************/
add_action( 'wp_ajax_rrac_show_aprt_det', 'rrac_show_aprt_det' );
add_action( 'wp_ajax_nopriv_rrac_show_aprt_det', 'rrac_show_aprt_det' );
function rrac_show_aprt_det(){

    global $wpdb;
    $table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
   	$id = $_POST['apartment_id'];
   	$sql_search = "select * from $table_name where id = ".$id;
	$search_re = $wpdb->get_row($sql_search);
	$result =array();
  $total_available = get_available_unit_count($search_re->api_response_id);
   	$str = '';
   	$str .='<div class="col-md-12">
   				<div class="col-md-6">';
   					$image_path = $search_re->image == ""?plugin_dir_url(__FILE__).'assets/images/no_image.png':$search_re->image;
                        $str .= '<img src="'.$image_path.'" width="100%" alt="" />
   				</div>
   				<div class="col-md-6">
   					<h3>'.$search_re->marketing_type.'</h3>
   					<div class="apt_details_single_line">
   					<span>'.$search_re->bedroom.'</span> Bed <span>'.$search_re->bathroom.'</span> Bath | <span>'.$search_re->size.'</span> Sq. Ft. | Starting At $<span>'.$total_available['unit_min_starting_price'].'</span>
   					</div>';

                  if($search_re->tagline != "")
                    $str .= '<div class="tagline">'.$search_re->tagline.'</div>';
                  
                  $str .= '<div class="apt_description">
   					'.$search_re->description.'
   					</div>
   					<div class="col-md-12">&nbsp;</div>
   					<div class="apt_button">
   						<a href="javascript:;" onclick="getUnitListByFloor('.$search_re->api_response_id.')" class="btn btn-info">See Availability <i class="fa fa-angle-right" aria-hidden="true"></i></a>
   						<span class="detLoad" style="display:none;"><img src="'.plugin_dir_url(__FILE__).'assets/images/loading.svg" width="70" alt="" /></span>
   					</div>
   				</div>
   			</div>';
   	$result['str'] = $str;
   	$result['name'] = $search_re->marketing_type;
   	echo json_encode($result);
    exit();
}
/************** Apartment Details ***************/


/************** getUnitListByFloor ***************/
add_action( 'wp_ajax_rrac_getUnitListByFloor', 'rrac_getUnitListByFloor' );
add_action( 'wp_ajax_nopriv_rrac_getUnitListByFloor', 'rrac_getUnitListByFloor' );

function rrac_getUnitListByFloor(){

    global $wpdb;
    $floorPlanID = $_POST['floorPlanID'];
    $moveindate = date('Y-m-d',strtotime($_POST['moveinDate']));


    /*---------New code base-------*/
    $unit_lists_json = '{}';
    if(file_exists(dirname(__FILE__).'/first_load_response.json'))
      $unit_lists_json = file_get_contents(dirname(__FILE__).'/first_load_response.json');
      $unit_lists_array = json_decode($unit_lists_json);

      $max_day = CALENDAR_UPCOMING_DAYS; ////to get max date
      $maxDate_by_api = date('Y-m-d', strtotime("+".$max_day." day", strtotime(date('Y-m-d'))));

      $maxDate = date('Y-m-d', strtotime("+".RESULT_SHOW_NEXT_DAYS." day", strtotime($moveindate)));
      if($maxDate > $maxDate_by_api)
      {
        $maxDate =  $maxDate_by_api;
      }

      $rowCount = 0;
      $result =array();
      $str = '';

      if($unit_lists_array)
      {
          $str_datepicker = '';
          $str_datepicker .='<div class="col-md-12 dat_fl">
                <div class="col-md-2 col-sm-12 col-xs-12">
                &nbsp
                </div>
                <div class="col-md-3 col-sm-12 col-xs-12">
                  <label>Desired Move-In Date</label>
                </div>
                <div class="col-md-5 col-sm-12 col-xs-12">
                  <input type="text" class="form-control" name="move_in_date" id="move_in_date" value="'.$_POST['moveinDate'].'"/>
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12">
                &nbsp
                </div>
              </div>
              <div class="col-md-12">&nbsp;</div>
              ';


          foreach ($unit_lists_array as $key => $unit_lists) 
          {

            if($key == 'floor_plan_'.$floorPlanID)
            {
              if(isset($unit_lists->{'@attributes'})){
                $fetched_date = $unit_lists->{'@attributes'}->available_date;
              } else {
                $fetched_date = '';
              }
               //print_r($unit_lists->ListResponse->ListResult->UnitObject);
              // print_r($fetched_date);
              // print_r($maxDate);
              //if($fetched_date)
              {
                 if(strtotime($maxDate) <= strtotime($fetched_date))
                 {


                    if(isset($unit_lists->ListResponse->ListResult->UnitObject))
                    {

                        $str .='<span class="desiredEmptyMessage"></span>
                                  <div class="rrac_listAvailableUnit">
                                    <table class="table">
                                      <tr>
                                        <th>Unit Number</th>
                                        
                                        <th>Starting At</th>
                                        <th>Deposit</th>
                                        <th>Availability</th>
                                        <th>Lease Now</th>
                                      </tr>';

                        if(is_array($unit_lists->ListResponse->ListResult->UnitObject))
                        {

                            foreach($unit_lists->ListResponse->ListResult->UnitObject as $res)
                            {
                              $moveindateResultNext = date('Y-m-d', strtotime("+".RESULT_SHOW_NEXT_DAYS." day", strtotime($moveindate)));
                              $moveindateResultPrev = date('Y-m-d', strtotime("-".RESULT_SHOW_PREV_DAYS." day", strtotime($moveindate)));
                              $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));

                              if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $moveindateResultNext)
                              {
                                if(date('Y-m-d',strtotime($res->Availability->MadeReadyDate)) <= date('Y-m-d')) 
                                  $availableData = 'Available Now'; 
                                else 
                                  $availableData = $res->Availability->MadeReadyDate;

                                $startingAtPrice = $res->BaseRentAmount;
                                if(isset($res->rentMatrix->row))
                                {
                                    //echo "<pre>";
                                    $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
                                    $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
                                    //print_r($rentMatrix['@attributes']);
                                }
                                  
                                $str .='<tr>
                                      <td><span>Unit Number</span>'.$res->Address->UnitNumber.'</td>
                                      
                                      <td><span>Starting At</span>$'.number_format((float)$startingAtPrice,2).'</td>
                                      <td><span>Deposit</span>$'.$res->DepositAmount.'</td>
                                      <td><span>Availability</span>'.$availableData.'</td>
                                      <td><a href="javascript:;" onclick="goto_lease(\''.$res->Address->UnitID.'\',\''.date('m/d/Y',strtotime($res->Availability->MadeReadyDate)).'\')">Lease Now</a></td>
                                    </tr>';
                                $rowCount++;
                              } 
                            }
                        }
                        else
                        {

                          $res = $unit_lists->ListResponse->ListResult->UnitObject;
                          $moveindateResultNext = date('Y-m-d', strtotime("+".RESULT_SHOW_NEXT_DAYS." day", strtotime($moveindate)));
                          $moveindateResultPrev = date('Y-m-d', strtotime("-".RESULT_SHOW_PREV_DAYS." day", strtotime($moveindate)));
                          $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));

                          if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $moveindateResultNext)
                          {
                            if(date('Y-m-d',strtotime($res->Availability->MadeReadyDate)) <= date('Y-m-d')) 
                              $availableData = 'Available Now'; 
                            else 
                              $availableData = $res->Availability->MadeReadyDate;

                            $startingAtPrice = $res->BaseRentAmount;
                            if(isset($res->rentMatrix->row))
                            {
                                //echo "<pre>";
                                $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
                                $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
                                //print_r($rentMatrix['@attributes']);
                            }
                              
                             $str .='<tr>
                                  <td><span>Unit Number</span>'.$res->Address->UnitNumber.'</td>
                                  
                                  <td><span>Starting At</span>$'.number_format((float)$startingAtPrice,2).'</td>
                                  <td><span>Deposit</span>$'.$res->DepositAmount.'</td>
                                  <td><span>Availability</span>'.$availableData.'</td>
                                  <td><a href="javascript:;" onclick="goto_lease(\''.$res->Address->UnitID.'\',\''.date('m/d/Y',strtotime($res->Availability->MadeReadyDate)).'\')">Lease Now</a></td>
                                </tr>';
                          }

                          $rowCount = 1;

                        }


                        $str .='</table></div>';
                    }
                    else
                    {
                      $str ='<span class="desiredEmptyMessage">Change Desired Move-In Date</span>';
                      $str_datepicker ='<div class="col-md-12 dat_fl">
                          <div class="col-md-2 col-sm-12 col-xs-12">
                          &nbsp
                          </div>
                          <div class="col-md-3 col-sm-12 col-xs-12">
                            <label>Desired Move-In Date</label>
                          </div>
                          <div class="col-md-5 col-sm-12 col-xs-12">
                            <input type="text" class="form-control" name="move_in_date" id="move_in_date" value="'.$_POST['moveinDate'].'"/>
                          </div>
                          <div class="col-md-2 col-sm-12 col-xs-12">
                          &nbsp
                          </div>
                        </div>
                        <div class="col-md-12">&nbsp;</div>
                        '.$str.'
                        ';
                      $str = ''; /// remove string
                    
                    }
                 }
              }
          
            }
            
          }
      }

    /*---------New code base-------*/

    //---------old value-------//

/*    $unit_lists = unit_list_by_floorPlanID($floorPlanID , $moveindate);
	  $result =array();
   	$str = '';
   	$str_datepicker = '';
   	$str_datepicker .='<div class="col-md-12 dat_fl">
   				<div class="col-md-2 col-sm-12 col-xs-12">
   				&nbsp
   				</div>
   				<div class="col-md-3 col-sm-12 col-xs-12">
   					<label>Desired Move-In Date</label>
   				</div>
   				<div class="col-md-5 col-sm-12 col-xs-12">
   					<input type="text" class="form-control" name="move_in_date" id="move_in_date" value="'.$_POST['moveinDate'].'"/>
   				</div>
   				<div class="col-md-2 col-sm-12 col-xs-12">
   				&nbsp
   				</div>
   			</div>
   			<div class="col-md-12">&nbsp;</div>
   			';

   	if(isset($unit_lists->ListResponse->ListResult->UnitObject))
   	{
   		$str .='
   			<span class="desiredEmptyMessage"></span>
   			<div class="rrac_listAvailableUnit">
   			<table class="table">
   				<tr>
   				  <th>Unit Number</th>
   				  <th>Floor</th>
   				  <th>Starting At</th>
   				  <th>Deposit</th>
   				  <th>Availability</th>
   				  <th>Lease Now</th>
   				</tr>
   		';
   		$rowCount = 0;
   		foreach($unit_lists->ListResponse->ListResult->UnitObject as $res)
   		{
   			$moveindateResultNext = date('Y-m-d', strtotime("+".RESULT_SHOW_NEXT_DAYS." day", strtotime($moveindate)));
   			$moveindateResultPrev = date('Y-m-d', strtotime("-".RESULT_SHOW_PREV_DAYS." day", strtotime($moveindate)));
			  $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));

   			if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $moveindateResultNext)
   			{
	   			if(date('m/d/Y',strtotime($res->Availability->MadeReadyDate)) <= date('m/d/Y')) 
	   				$availableData = 'Available Now'; 
	   			else 
	   				$availableData = $res->Availability->MadeReadyDate;

          $startingAtPrice = $res->BaseRentAmount;
          if(isset($res->rentMatrix->row))
          {
              //echo "<pre>";
              $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
              $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
              //print_r($rentMatrix['@attributes']);
          }
            
	   			$str .='<tr>
		   				  <td><span>Unit Number</span>'.$res->Address->UnitNumber.'</td>
		   				  <td><span>Floor</span>'.$res->UnitDetails->FloorNumber.'</td>
		   				  <td><span>Starting At</span>$'.number_format((float)$startingAtPrice,2).'</td>
		   				  <td><span>Deposit</span>$'.$res->DepositAmount.'</td>
		   				  <td><span>Availability</span>'.$availableData.'</td>
		   				  <td><span>Lease Now</span><a href="javascript:;" onclick="goto_lease(\''.$res->Address->UnitID.'\',\''.date('m/d/Y',strtotime($res->Availability->MadeReadyDate)).'\')">Lease Now</a></td>
		   				</tr>';
		   		$rowCount++;
		   	}	
   		}
   		$str .='</table>
   			</div>
   		';
   	}
   	else
   	{
   		$str ='<span class="desiredEmptyMessage">Change Desired Move-In Date</span>';
   		$str_datepicker ='<div class="col-md-12 dat_fl">
   				<div class="col-md-2 col-sm-12 col-xs-12">
   				&nbsp
   				</div>
   				<div class="col-md-3 col-sm-12 col-xs-12">
   					<label>Desired Move-In Date</label>
   				</div>
   				<div class="col-md-5 col-sm-12 col-xs-12">
   					<input type="text" class="form-control" name="move_in_date" id="move_in_date" value="'.$_POST['moveinDate'].'"/>
   				</div>
   				<div class="col-md-2 col-sm-12 col-xs-12">
   				&nbsp
   				</div>
   			</div>
   			<div class="col-md-12">&nbsp;</div>
   			'.$str.'
   			';
   		$str = ''; /// remove string
		
   	}*/

    //---------old value-------//

    //-------next available slots-------//

   	if($rowCount == 0)
   	{
      $max_day = CALENDAR_UPCOMING_DAYS - RESULT_SHOW_NEXT_DAYS; ////to get max date
      $maxDate = date('Y-m-d', strtotime("+".$max_day." day", strtotime(date('Y-m-d'))));
      $unit_lists_next_available = unit_list_by_floorPlanID($floorPlanID , $maxDate);
      $next_Available = "";
      $next_Available_date_msg = "";
      foreach($unit_lists_next_available->ListResponse->ListResult->UnitObject as $res_next_available)
      {
       //print_r($res_next_available);
        if( date('Y-m-d',strtotime($res_next_available->Availability->MadeReadyDate)) >= $moveindate)
        {
            if($next_Available == ""){ 
              $next_Available = $res_next_available->Availability->MadeReadyDate;
            }
            else if(date('Y-m-d',strtotime($next_Available)) > date('Y-m-d',strtotime($res_next_available->Availability->MadeReadyDate)) )
            {
              $next_Available = $res_next_available->Availability->MadeReadyDate;
            }
        }
      }
      if($next_Available != "")
      {
        $next_Available_date_msg = "Next Availble On: ".$next_Available;
      }
      else
      {
        $next_Available_date_msg = 'Unit Not Availble. <a href="javascript:;" onclick="getContactFormSlide()">Contact Us</a>';
      }
   		$str ='<span class="desiredEmptyMessage">Change Desired Move-In Date <span class="nextAvailable">'.$next_Available_date_msg.'</span> </span>
      ';
   		$str_datepicker ='<div class="col-md-12 dat_fl">
   				<div class="col-md-2 col-sm-12 col-xs-12">
   				&nbsp
   				</div>
   				<div class="col-md-3 col-sm-12 col-xs-12">
   					<label>Desired Move-In Date</label>
   				</div>
   				<div class="col-md-5 col-sm-12 col-xs-12">
   					<input type="text" class="form-control" name="move_in_date" id="move_in_date" value="'.$_POST['moveinDate'].'"/>
   				</div>
   				<div class="col-md-2 col-sm-12 col-xs-12">
   				&nbsp
   				</div>
   			</div>
   			<div class="col-md-12">&nbsp;</div>
   			'.$str.'
   			';
   		$str = '';/// remove string
   	}

    //-------next available slots-------//

    if(empty($result))
    {
        $result['str'] = $str_datepicker.$str;
        $result['name'] = $search_re->marketing_type;
        echo json_encode($result);
    }


    exit();
}
/************** getUnitListByFloor ***************/


/************** getContact Form ***************/
add_action( 'wp_ajax_rrac_getContactForm', 'rrac_getContactForm' );
add_action( 'wp_ajax_nopriv_rrac_getContactForm', 'rrac_getContactForm' );
function rrac_getContactForm(){
    global $wpdb;
    $str ='<div class="ContactFormArea contact-us-popup">';
    $str .= '<h3>Feel free to ask your query.</h3>';
    $str .= '<form class="rrac_contactForm" id="rrac_contactForm" action="javascript:;" onsubmit="return rrac_contactFormSubmit()">
            <div class="form-group col-md-12 col-sm-12 col-xs-12">
              <input type="text" class="form-control" placeholder="First Name*" name="first_name" required>
            </div>
            <div class="form-group col-md-12 col-sm-12 col-xs-12">
              <input type="text" class="form-control" placeholder="Last Name*" name="last_name" required>
            </div>
            <div class="form-group col-md-12 col-sm-12 col-xs-12">
              <input type="tel" class="form-control" placeholder="Phone No*" name="phone" required>
            </div>
            <div class="form-group col-md-12 col-sm-12 col-xs-12">
              <input type="email" class="form-control" placeholder="Email*" name="email" required>
            </div>
            <div class="form-group col-md-12 col-sm-12 col-xs-12">
              <textarea class="form-control" placeholder="Message" name="message"></textarea>
            </div>
          
          <div class="form-group col-md-12 col-sm-12 col-xs-12 apt_button">
            <button type="submit" class="btn btn-default">Submit</button>
            <span class="detLoad" style="display:none;"><img src="'.plugin_dir_url(__FILE__).'assets/images/loading.svg" width="70" alt="" /></span>
            </div>
          </form>';
    $str .= '</div>';
        echo $str;
        exit;
}

/************** Contact Form Submit***************/
add_action( 'wp_ajax_rrac_submitContactForm', 'rrac_submitContactForm' );
add_action( 'wp_ajax_nopriv_rrac_submitContactForm', 'rrac_submitContactForm' );
function rrac_submitContactForm(){

    global $wpdb;
    $table_name = $wpdb->prefix.'rrac_floorplan_marketing_type';
    $current_floorplan_id = $_POST['current_floorplan_id'];
    $sql_search = "select * from $table_name where api_response_id = ".$current_floorplan_id;
    $search_re = $wpdb->get_row($sql_search);
    unset($_POST['current_floorplan_id']);
    unset($_POST['action']);
    $_POST['apartment'] = $search_re->marketing_type.' ('.$search_re->floorplan_code.')';
    // recipients
    $to = get_option('rrac_contact_email'); // note the comma
    if($to == '')
    {
       $to = get_option('admin_email');
    }
    // Subject
    $subject = get_bloginfo('name').' - Apartment Query';

    
    // Message
    $message = '';
    if(isset($_POST))
    {
      foreach($_POST as $key => $value)
      {
        $message .= '<b>'.ucfirst($key). '</b> : '.$value . '<br>';
      }
    }

    // To send HTML mail, the Content-type header must be set
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-type: text/html; charset=iso-8859-1';

    // Additional headers
    $headers[] = 'From: '.$_POST['first_name'].' <'.$_POST['email'].'>';
    //$headers[] = 'Cc: birthdayarchive@example.com';
    //$headers[] = 'Bcc: birthdaycheck@example.com';

    // Mail it
    if(mail($to, $subject, $message, implode("\r\n", $headers)) )
    {
      echo 1;
    }
    else
    {
      echo 0;
    }
    exit;

}


/************** Apartment Delete ***************/
add_action( 'wp_ajax_rrac_delApartment', 'rrac_delApartment' );
//add_action( 'wp_ajax_nopriv_rrac_delApartment', 'rrac_delApartment' );
function rrac_delApartment(){

    global $wpdb;
    $table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
   	$id = $_POST['idd'];
   	$sql_search = "delete from $table_name where id = ".$id;
	$search_re = $wpdb->query($sql_search);
	$result =array();
   	echo 1;   	
    exit();
}

/************** Apartment Delete selected ***************/
add_action( 'wp_ajax_rrac_delSelectedApartment', 'rrac_delSelectedApartment' );
//add_action( 'wp_ajax_nopriv_rrac_delSelectedApartment', 'rrac_delSelectedApartment' );
function rrac_delSelectedApartment(){

    global $wpdb;
    $table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
    foreach($_POST['deleteItem'] as $id)
   	{
	   	$sql_search = "delete from $table_name where id = ".$id;
		$search_re = $wpdb->query($sql_search);
	}
	$result =array();
   	echo 1;   	
    exit();
}


/**************UnInstall Functions ***************/
function rrac_unInstall() {
	global $wpdb;
	global $rrac_version;

	$table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
	
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "DROP TABLE $table_name";
	$wpdb->query( $sql );

	rrac_remove_default_datas();
	
}

function rrac_remove_default_datas()
{
	delete_option( 'rrac_version');
	delete_option( 'realpage_api_user');
	delete_option( 'realpage_api_password');
	delete_option( 'realpage_api_siteid');
	delete_option( 'realpage_api_pmcid');
	delete_option( 'site_available_page_url');

	delete_option( 'rrac_default_color_text' );

	delete_option( 'rrac_tab_area_background' );
	delete_option( 'rrac_tab_heading_background' );
	delete_option( 'rrac_tab_heading_text' );
	delete_option( 'rrac_tab_heading_background_active' );
	delete_option( 'rrac_tab_heading_text_active' );

	delete_option( 'rrac_tab_content_background' );
	delete_option( 'rrac_tab_content_border_bottom' );
	delete_option( 'rrac_appartment_title' );
	delete_option( 'rrac_appartment_tagline' );
	delete_option( 'rrac_appartment_highlighted_text' );
	delete_option( 'rrac_button_background' );
	delete_option( 'rrac_button_border' );
	delete_option( 'rrac_button_text');
	delete_option( 'rrac_button_background_hover' );
	delete_option( 'rrac_button_text_hover' );

  delete_option( 'rrac_btn_border_radius');
  delete_option( 'rrac_tab_heading_border_radius');

	delete_option( 'rrac_modal_content_heading' );
	delete_option( 'rrac_modal_table_border' );
	delete_option( 'rrac_modal_datepickert_active' );
	delete_option( 'rrac_modal_datepickert_active_background' );
	delete_option( 'rrac_modal_lease_now_button' );
	delete_option( 'rrac_modal_lease_now_button_background' );

	delete_option( 'rrac_own_css' );
  delete_option('rrac_contact_email');
}

/**************UnInstall Functions ***************/

/**************Default data add ***************/
function rrac_default_color_dataset($force = 0)
{
	update_option_check( 'rrac_default_color_text', '#555555' , $force);

	update_option_check( 'rrac_tab_area_background', '#ffffff' , $force);
	update_option_check( 'rrac_tab_heading_background', '#444444' , $force);
	update_option_check( 'rrac_tab_heading_text', '#ffffff' , $force);
	update_option_check( 'rrac_tab_heading_background_active', '#da6761' , $force);
	update_option_check( 'rrac_tab_heading_text_active', '#ffffff' , $force);

	update_option_check( 'rrac_tab_content_background', '#ffffff' , $force);
	update_option_check( 'rrac_tab_content_border_bottom', '#c4c4c4' , $force);
	update_option_check( 'rrac_appartment_title', '#1a9d97' , $force);
	update_option_check( 'rrac_appartment_tagline', '#000000' , $force);
	update_option_check( 'rrac_appartment_highlighted_text', '#154780' , $force);
	update_option_check( 'rrac_button_background', '#408080' , $force);
	update_option_check( 'rrac_button_border', '#408080' , $force);
	update_option_check( 'rrac_button_text', '#ffffff' , $force);
	update_option_check( 'rrac_button_background_hover', '#2e5c5c' , $force);
	update_option_check( 'rrac_button_text_hover', '#ffffff' , $force);

	update_option_check( 'rrac_secondary_button_background', '#ffffff' , $force);
	update_option_check( 'rrac_secondary_button_border', '#2e5c5c' , $force);
	update_option_check( 'rrac_secondary_button_text', '#408080' , $force);
	update_option_check( 'rrac_secondary_button_background_hover', '#2e5c5c' , $force);
	update_option_check( 'rrac_secondary_button_text_hover', '#ffffff' , $force);

  update_option_check( 'rrac_btn_border_radius', '0' , $force);
  update_option_check( 'rrac_tab_heading_border_radius', '0' , $force);

	update_option_check( 'rrac_modal_content_heading', '#666666' , $force);
	update_option_check( 'rrac_modal_table_border', '#cccccc' , $force);
	update_option_check( 'rrac_modal_datepickert_active', '#ffffff' , $force);
	update_option_check( 'rrac_modal_datepickert_active_background', '#444444' , $force);
	update_option_check( 'rrac_modal_lease_now_button', '#ffffff' , $force);
	update_option_check( 'rrac_modal_lease_now_button_background', '#666666' , $force);
}


function rrac_default_color_dataset_list_view_2()
{
	update_option( 'rrac_default_color_text', '#555555' );

	update_option( 'rrac_tab_area_background', '#ffffff' );
	update_option( 'rrac_tab_heading_background', '#F8F8F8' );
	update_option( 'rrac_tab_heading_text', '#1A9D97' );
	update_option( 'rrac_tab_heading_background_active', '#CABE9F' );
	update_option( 'rrac_tab_heading_text_active', '#ffffff' );

	update_option( 'rrac_tab_content_background', '#ffffff' );
	update_option( 'rrac_tab_content_border_bottom', '#c4c4c4' );
	update_option( 'rrac_appartment_title', '#2BA49E' );
	update_option( 'rrac_appartment_tagline', '#000000' );
	update_option( 'rrac_appartment_highlighted_text', '#4FB3AF' );
	update_option( 'rrac_button_background', '#FFFFFF' );
	update_option( 'rrac_button_border', '#4FB3AF' );
	update_option( 'rrac_button_text', '#34A8A3' );
	update_option( 'rrac_button_background_hover', '#34A8A3' );
	update_option( 'rrac_button_text_hover', '#ffffff' );

	update_option( 'rrac_secondary_button_background', '#ffffff' );
	update_option( 'rrac_secondary_button_border', '#4FB3AF' );
	update_option( 'rrac_secondary_button_text', '#34A8A3' );
	update_option( 'rrac_secondary_button_background_hover', '#34A8A3' );
	update_option( 'rrac_secondary_button_text_hover', '#ffffff' );

  update_option( 'rrac_btn_border_radius', '0' );
  update_option( 'rrac_tab_heading_border_radius', '0' );

	update_option( 'rrac_modal_content_heading', '#666666' );
	update_option( 'rrac_modal_table_border', '#cccccc' );
	update_option( 'rrac_modal_datepickert_active', '#ffffff' );
	update_option( 'rrac_modal_datepickert_active_background', '#444444' );
	update_option( 'rrac_modal_lease_now_button', '#ffffff' );
	update_option( 'rrac_modal_lease_now_button_background', '#666666' );
}

function update_option_check($key , $value , $force)
{
    if($force == 1)
    {
      update_option($key , $value);
    }
    else
    {
      if(!get_option($key))
      {
        update_option($key , $value);
      }
    }
}
/**************Default data add ***************/

/************** Apartment Delete selected ***************/
add_action( 'wp_ajax_rrac_setDefaultColors', 'rrac_setDefaultColors' );
function rrac_setDefaultColors(){

    global $wpdb;
    $template = $_POST['template'];
    if($template == 'list_view_1')
    	rrac_default_color_dataset(1);
    else
    	rrac_default_color_dataset_list_view_2();
   	echo 1;   	
    exit();
}

/************** Tab Heading ***************/
add_action( 'wp_ajax_rrac_tab_heading_save', 'rrac_tab_heading_save' );
function rrac_tab_heading_save(){

    global $wpdb;
    //$table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
    $datas = $_POST;
    unset($datas['action']);
    unset($datas['submit']);
    $saveData = json_encode($datas);
    update_option('rrac_tab_heading' , $saveData);
    echo 1;
    exit;
}

/************** Tab Ordering ***************/
add_action( 'wp_ajax_rrac_tab_ordering', 'rrac_tab_ordering' );
function rrac_tab_ordering(){

    global $wpdb;
    $table_name = $wpdb->prefix . 'rrac_floorplan_group';
    $orderarray = $_POST['orderarray'];
    //print_r($orderarray[0]); 
    $orderarray = explode(',',$orderarray);
    $order_no = 0;
    foreach($orderarray as $order)
    {
      $sql = "UPDATE $table_name SET
          order_no = '".$order_no."'
          WHERE 
          id = '".$order."';
          ";
          //echo $sql;
        $wpdb->query($sql);
        $order_no++;
    }  
    echo 1;
    exit;
}

/////////////////////////
function get_available_unit_count($floorplanId)
 {
    global $wpdb;
    
    $calendarUpcomingDays = CALENDAR_UPCOMING_DAYS;
    $resultNextDay = RESULT_SHOW_NEXT_DAYS;
    $resultPrevDay = RESULT_SHOW_PREV_DAYS;
    
    $moveindateResultUpcoming = date('Y-m-d', strtotime("+".$calendarUpcomingDays." day", strtotime(date('Y-m-d'))));
    $moveindateResultNext = date('Y-m-d', strtotime("+".$resultNextDay." day", strtotime(date('Y-m-d'))));
    $moveindateResultPrev = date('Y-m-d', strtotime("-".$resultPrevDay." day", strtotime(date('Y-m-d'))));

    if(file_exists(dirname(__FILE__).'/first_load_response.json'))
    $unit_lists_json = file_get_contents(dirname(__FILE__).'/first_load_response.json');
    $unit_lists_array = json_decode($unit_lists_json);
    $results = false;
    $count = 0;
    $available_date_array = array();
    $unit_min_starting_price = 0;

    if($unit_lists_array)
    {

          foreach ($unit_lists_array as $key => $unit_lists) 
          {
            if($key == 'floor_plan_'.$floorplanId)
            {   

                  if(isset($unit_lists->ListResponse->ListResult->UnitObject))
                  {
                    if(!is_array($unit_lists->ListResponse->ListResult->UnitObject)) 
                    {
                        $res = $unit_lists->ListResponse->ListResult->UnitObject;

                        $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));
                        

                        if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $moveindateResultNext )
                        {
                          $startingAtPrice = $res->BaseRentAmount;
                          if(isset($res->rentMatrix->row))
                          {
                              $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
                              $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
                          }

                          if($count == 0)
                          {
                            $unit_min_starting_price = number_format((float)$startingAtPrice,2);
                          }
                          else
                          {
                            if($unit_min_starting_price > number_format((float)$startingAtPrice,2))
                                $unit_min_starting_price = number_format((float)$startingAtPrice,2);
                          }
                          
                          if(!in_array($MadeReadyDate , $available_date_array))
                          {
                            $available_date_array[] = $MadeReadyDate;
                          }
                          $count++;
                        }

                    } else {

                        foreach ($unit_lists->ListResponse->ListResult->UnitObject as $res) 
                        {
                          $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));
                          if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $moveindateResultNext )
                          {
                            $startingAtPrice = $res->BaseRentAmount;

                            if(isset($res->rentMatrix->row))
                            {
                                $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
                                $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
                            }

                            if($count == 0)
                            {
                              $unit_min_starting_price = number_format((float)$startingAtPrice,2);
                            }
                            else
                            {
                              if($unit_min_starting_price > number_format((float)$startingAtPrice,2))
                                  $unit_min_starting_price = number_format((float)$startingAtPrice,2);
                            }
                            
                            if(!in_array($MadeReadyDate , $available_date_array))
                            {
                              $available_date_array[] = $MadeReadyDate;
                            }
                            $count++;
                          }
                        }
                      }
                  
                  } 

                  $rrac_display_max_available_unit = get_option('rrac_display_max_available_unit');
                  if($rrac_display_max_available_unit == '') 
                    $show_available = $count;
                  else if($rrac_display_max_available_unit < $count)
                    $show_available = $rrac_display_max_available_unit;
                  else
                    $show_available = $count;
                
                  $results['count'] = $show_available;
                  $results['available_date'] = $available_date_array;
                  $results['unit_min_starting_price'] = $unit_min_starting_price; 
            }
          }
    }

    if($results) {
      return $results;
    }

      /*
      $unit_lists = unit_list_by_floorPlanID($floorplanId , $moveindateResultUpcoming );
      $count = 0;
      $available_date_array = array();
      $unit_min_starting_price = 0;
      if(isset($unit_lists->ListResponse->ListResult->UnitObject))
      {
        foreach($unit_lists->ListResponse->ListResult->UnitObject as $res)
        {
            $MadeReadyDate = date('Y-m-d', strtotime($res->Availability->MadeReadyDate));
            if($MadeReadyDate >= $moveindateResultPrev && $MadeReadyDate <= $moveindateResultUpcoming)
            {
              $startingAtPrice = $res->BaseRentAmount;
              if(isset($res->rentMatrix->row))
              {
                  $rentMatrix = json_decode(json_encode($res->rentMatrix->row), true);
                  $startingAtPrice =  $rentMatrix['@attributes']['MinRent'];
              }

              if($count == 0)
              {
                $unit_min_starting_price = number_format((float)$startingAtPrice,2);
              }
              else
              {
                if($unit_min_starting_price > number_format((float)$startingAtPrice,2))
                    $unit_min_starting_price = number_format((float)$startingAtPrice,2);
              }
              
              if(!in_array($MadeReadyDate , $available_date_array))
              {
                $available_date_array[] = $MadeReadyDate;
              }
              $count++;
            }
        }
      }
      $results['count'] = $count;
      $results['available_date'] = $available_date_array;
      $results['unit_min_starting_price'] = $unit_min_starting_price;
      return $results;*/

    
 }

 /************** unitStatusChange  ***************/
add_action( 'wp_ajax_rrac_unitStatusChange', 'rrac_unitStatusChange' );
function rrac_unitStatusChange(){

    global $wpdb;
    $floor_unit = $_POST['floor_unit'];
    $status = $_POST['status'];
    $unit_status_array = array();
    if(file_exists(dirname(__FILE__).'/unit_status.json')){
      $unit_status_json = file_get_contents(dirname(__FILE__).'/unit_status.json');
      $unit_status_array = json_decode($unit_status_json , true);
      $unit_status_array[$floor_unit] = $status;
      
    }
    else
    {
      $unit_status_array[$floor_unit] = $status;
    }

    $write_content = json_encode($unit_status_array);
    $far = fopen(dirname(__FILE__).'/unit_status.json', 'w');
    fwrite($far, $write_content);
    fclose($far);
    echo 1;
    exit;
}

/*************************Group Management******************************/
add_action( 'wp_ajax_rrac_group_addedit', 'rrac_group_addedit' );
//add_action( 'wp_ajax_nopriv_rrac_configuration_add', 'rrac_configuration_add' );
function rrac_group_addedit(){
    global $wpdb;
    unset($_POST['action']);
    unset($_POST['Save']);
    $table_name = $wpdb->prefix . 'rrac_floorplan_group';
    if(isset($_POST['idd']) && $_POST['idd'] != "")
    {
        $sql = "UPDATE $table_name SET
          group_name = '".$_POST['group_name']."',
          bedroom = '".$_POST['bedroom']."',
          description = '".$_POST['description']."',
          status = '".$_POST['status']."'
          
          WHERE
          id = '".$_POST['idd']."'
          ;
          ";
    }
    else
    {
        $sql = "INSERT INTO $table_name SET
          group_name = '".$_POST['group_name']."',
          bedroom = '".$_POST['bedroom']."',
          description = '".$_POST['description']."',
          status = '".$_POST['status']."'
          ;
          ";
    }
    $wpdb->query($sql);
    echo 1;
    exit();
}
/************** Site Delete ***************/
add_action( 'wp_ajax_rrac_delGroup', 'rrac_delGroup' );
//add_action( 'wp_ajax_nopriv_rrac_delApartment', 'rrac_delApartment' );
function rrac_delGroup(){
    global $wpdb;
    $id = $_POST['idd'];
    
    $table_name = $wpdb->prefix . 'rrac_floorplan_group';
    $sql_delete_site = "delete from $table_name where id = ".$id;  //Auto delete floorplan related to this site(because of forign key relation)
    $delete_site = $wpdb->query($sql_delete_site);
    $result =array();
    echo 1;     
    exit();
}
/*************************Group Management******************************/


/************** Check Update ***************/
add_action( 'wp_ajax_rrac_check_for_update', 'rrac_check_for_update' );
//add_action( 'wp_ajax_nopriv_rrac_delApartment', 'rrac_delApartment' );
function rrac_check_for_update(){
    global $wpdb;
    $current_version = RRAC_PLUGIN_VERSION;
    $plugin_store_url = RRAC_PLUGIN_URL;
    $plugin_store_user_name = 'userName';
    $plugin_store_user_pass = 'userPass';
    $plugin_store_id = STORE_PLUGIN_ID;
    ///////////CURL
    $ch = curl_init();
    $skipper = "luxury assault recreational vehicle";
    $fields = array( 'user'=>$plugin_store_user_name, 'pass'=>$plugin_store_user_pass , 'plugin_store_id' => $plugin_store_id, 'action'=>'get_latest_version_info');
    $postvars = '';
    foreach($fields as $key=>$value) {
      $postvars .= $key . "=" . $value . "&";
    }
    $url = $plugin_store_url.'/api_request.php';
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_POST, 1);                //0 for a get request
    curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
    curl_setopt($ch,CURLOPT_TIMEOUT, 20);
    $response = curl_exec($ch);
    curl_close ($ch);
    if($response)
    {
      $res = json_decode($response,true);
      if(isset($res['status']) && $res['status'] == 200 )
      {
        $message_zip = "";
        try{
            $zip = new ZipArchive;
            $zip->close();
        }
        catch (customException $e) {
          $message_zip = "ZipArchive not install in your server. Please install this extention first.";
        }
        
        

        $latest_ver = $res['result']['version'];
        if($latest_ver > $current_version){
          echo "Version ".$latest_ver." Available.";
          if($message_zip == ""){
           echo "<a href='javascript:;' onclick=\"get_updated_file('".base64_encode($res['result']['file'])."');\">Click here</a> to update latest version.";
          }
          else
          {
            echo $message_zip;
          }
        }
        else{
          update_option('rrac_update_status','');
          echo "Current installed version is upto date.";
        }
      }
      else
      {
        if(isset($res['message'])) 
          echo $res['message'];
        else
          echo "Internal Error. Try Again.";
      }
    }

    //echo $current_version;     
    exit();
}

/************** Download Update File ***************/
add_action( 'wp_ajax_rrac_update_version_file_download', 'rrac_update_version_file_download' );
//add_action( 'wp_ajax_nopriv_rrac_delApartment', 'rrac_delApartment' );
function rrac_update_version_file_download(){
    global $wpdb;
    $current_version = RRAC_PLUGIN_VERSION;
    $plugin_store_url = RRAC_PLUGIN_URL;
    $plugin_store_url = RRAC_PLUGIN_URL;
    $filepath = base64_decode($_POST['filepath']);
    $zip_name = basename($filepath);
    ///////////CURL
    $ch = curl_init();
    $skipper = "luxury assault recreational vehicle";
    $fields = array( );
    $postvars = '';
    foreach($fields as $key=>$value) {
      $postvars .= $key . "=" . $value . "&";
    }
    $url = $plugin_store_url.'/'.$filepath;
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_POST, 1);                //0 for a get request
    curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
    curl_setopt($ch,CURLOPT_TIMEOUT, 20);
    $response = curl_exec($ch);
    curl_close ($ch);
    if($response)
    {
        $destination = plugin_dir_path(__DIR__).$zip_name;
        $file = fopen($destination, "w+");
        fputs($file, $response);
        fclose($file);
        //echo $response;
        ////////Extract Code
        $zip = new ZipArchive;
        $res = $zip->open($destination);
        if ($res === TRUE)
        {
            echo 'ok';
            update_option('rrac_update_status',0);
            $zip->extractTo(plugin_dir_path(__DIR__));
            $zip->close();
            @unlink($destination);
            rrac_install();
        }
        else {
            die("Failed");
        }
    }

    //echo $current_version;     
    exit();
}
/************** Floorplan Gallery Image Delete ***************/
add_action( 'wp_ajax_rrac_floorplan_gallery_image_delete', 'rrac_floorplan_gallery_image_delete' );
//add_action( 'wp_ajax_nopriv_rrac_delApartment', 'rrac_delApartment' );
function rrac_floorplan_gallery_image_delete(){
    global $wpdb;
    $imageUrl = $_POST['imageUrl'];
    $floorplanid = $_POST['floorplanid'];
    $table_name_marketing_type = $wpdb->prefix . 'rrac_floorplan_marketing_type';
    $sql_get_data = "select image_gallery from $table_name_marketing_type where id=".$floorplanid;
    $resData = $wpdb->get_row($sql_get_data);
    if($resData->image_gallery != "")
    {
      $image_gallery = explode(',', $resData->image_gallery);
      for($i=0; $i<count($image_gallery); $i++)
      {
        if($image_gallery[$i] == $imageUrl) unset($image_gallery[$i]);
      }
      $new_gallery = implode(',',$image_gallery);
      $sql_save_data = "update $table_name_marketing_type set image_gallery='".$new_gallery."' where id=".$floorplanid;
      $wpdb->query($sql_save_data);
      echo 1;
    }
    else
      echo 0;
    exit();
}
/************** Floorplan Gallery Light BOX ***************/
add_action( 'wp_ajax_rrac_show_floorplan_gallery', 'rrac_show_floorplan_gallery' );
add_action( 'wp_ajax_nopriv_rrac_show_floorplan_gallery', 'rrac_show_floorplan_gallery' );
function rrac_show_floorplan_gallery(){
    global $wpdb;
    $floorplanid = $_POST['id'];
    $table_name_marketing_type = $wpdb->prefix . 'rrac_floorplan_marketing_type';
    $sql_get_data = "select * from $table_name_marketing_type where id=".$floorplanid;
    $resData = $wpdb->get_row($sql_get_data, ARRAY_A);

    $images = array();
    $images_galleries = array();
    $virtual_tours = array();
    if($resData['image'] != "")
    {
        $images[] = $resData['image'];
    }
    if($resData['image_gallery'] != "")
    {
        $images_galleries = explode(',',$resData['image_gallery']);
    }
    if($resData['virtual_tour'] != "")
    {
        $virtual_tours = json_decode($resData['virtual_tour'] , true);
    }
    $str = "";
    if(count($images) > 0 || count($images_galleries) > 0 || count($virtual_tours) > 0)
    {
        $str.='<ul class="nav nav-tabs">';
        if(count($images) > 0 || count($images_galleries) > 0 )
          $str.='<li class="active"><a data-toggle="tab" href="#Floor_Plans">Floor Plans</a></li>';
        if(count($virtual_tours) > 0)
          $str.='<li><a data-toggle="tab" href="#Virtual_Tour">Virtual Tour</a></li>';
        $str.='</ul>';

        $str.='<div class="tab-content">';
        if(count($images) > 0 || count($images_galleries) > 0)
        {
          $str.='<div id="Floor_Plans" class="tab-pane fade in active">
              <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">';
                  $count = 0;
                  foreach($images as $image)
                  {
                      $activeClass = "";
                      if($count == 0) $activeClass = "active";
                      $str.='<li data-target="#myCarousel" data-slide-to="'.$count.'" class="'.$activeClass.'"></li>';
                      $count++;
                  }
                  foreach($images_galleries as $images_gallery)
                  {
                      $activeClass = "";
                      if($count == 0) $activeClass = "active";
                      $str.='<li data-target="#myCarousel" data-slide-to="'.$count.'" class="'.$activeClass.'"></li>';
                      $count++;
                  }
                $str.='</ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner">';
                $count = 0;
                foreach($images as $image)
                {
                  $activeClass = "";
                  if($count == 0) $activeClass = "active";
                  $str.='<div class="item '.$activeClass.'">
                    <img src="'.$image.'"  style="max-width:100%;">
                    <!--<div class="carousel-caption">
                      <h3>Los Angeles</h3>
                      <p>LA is always so much fun!</p>
                    </div>-->
                  </div>';
                  $count++;
                }
                foreach($images_galleries as $images_gallery)
                {
                  $activeClass = "";
                  if($count == 0) $activeClass = "active";
                  $str.='<div class="item '.$activeClass.'">
                    <img src="'.$images_gallery.'"  style="max-width:100%;">
                    <!--<div class="carousel-caption">
                      <h3>Los Angeles</h3>
                      <p>LA is always so much fun!</p>
                    </div>-->
                  </div>';
                  $count++;
                }
                $str.='</div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                  <span class="glyphicon glyphicon-chevron-left"><i class="fa fa-angle-left"></i></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                  <span class="glyphicon glyphicon-chevron-right"><i class="fa fa-angle-right"></i></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
          </div>';
        }
        if(count($virtual_tours) > 0)
        {
          $str.='<div id="Virtual_Tour" class="tab-pane fade">
            <div id="myCarousel2" class="carousel slide" data-ride="carousel">
              <!-- Indicators -->
              <ol class="carousel-indicators">';
                $count = 0;
                foreach($virtual_tours as $virtual_tour)
                {
                    $activeClass = "";
                    if($count == 0) $activeClass = "active";
                    $str.='<li data-target="#myCarousel2" data-slide-to="'.$count.'" class="'.$activeClass.'"></li>';
                    $count++;
                }
                $str.='</ol>

              <!-- Wrapper for slides -->
              <div class="carousel-inner">';
                $count = 0;
                foreach($virtual_tours as $virtual_tour)
                {
                  $activeClass = "";
                  if($count == 0) $activeClass = "active";
                $str.='<div class="item '.$activeClass.'">
                       <input type="hidden" class="hidden_iframe_src" />
                    '.$virtual_tour.'                     
                  </div>';
                $count++;
              }
              $str.='
              </div>

              <!-- Left and right controls -->
              <a class="left carousel-control" href="#myCarousel2" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"><i class="fa fa-angle-left"></i></span>
                <span class="sr-only"></span>
              </a>
              <a class="right carousel-control" href="#myCarousel2" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"><i class="fa fa-angle-right"></i></span>
                <span class="sr-only"></span>
              </a>
            </div>
          </div>';
        } 
        $str.='</div>';

        $str.='<script>
          jQuery(document).ready(function(){
                jQuery("#myCarousel2 .item").each(function(){
                      var src = jQuery(this).find("iframe").get(0);
                      if(src != undefined)
                      {
                          var srcS = src.src;
                          var hidFild = jQuery(this).find(".hidden_iframe_src");
                          hidFild.val(srcS);
                      }
                      
                  });
            });
            jQuery("#myCarousel2").carousel({
              interval: false
            }).on("slide.bs.carousel", function () {
              //console.log(jQuery("#myCarousel2 .item.active").find("iframe").get(0));
              //var player = jQuery("#myCarousel2 .item.active").find("iframe").get(0);
              jQuery("#myCarousel2 .item").each(function(){
                    if(jQuery(this).hasClass("active"))
                    {
                      var src = jQuery(this).find("iframe").get(0);
                      if(src != undefined)
                      {
                        //var srcS = src.src;
                        var hidFild = jQuery(this).find(".hidden_iframe_src").val();
                        setTimeout(function(){
                            src.src = hidFild;
                          },500);
                      }
                    }
                    
                      
                  });
             
            });
        </script>';
    }
    else
    {
       $str .='Gallery Not Available.';
    }
    echo $str;
    //echo 1;
    exit();
}


?>