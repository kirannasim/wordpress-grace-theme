<?php
/**
 * Plugin Name: REPLI ApartmentSync
 * Plugin URI: http://phpstack-269994-1058827.cloudwaysapps.com/
 * Description: Get Floor plan from realpage API.
 * Version: 1.4.1
 * Author: Repli
 * Author URI: http://phpstack-269994-1058827.cloudwaysapps.com/
 */

require_once(ABSPATH.'wp-load.php');

if( !function_exists('get_plugin_data') ){
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
$plugin_data = get_plugin_data( __FILE__ );
//print_r($plugin_data);
$plugin_name = $plugin_data['Name'];
$plugin_version = $plugin_data['Version'];
$plugin_url = $plugin_data['PluginURI'];
define('RRAC_PLUGIN_NAME', $plugin_name);
define('RRAC_PLUGIN_VERSION', $plugin_version);
define('RRAC_PLUGIN_URL', $plugin_url);
define('STORE_PLUGIN_ID',5);

$all_options['realpage_api_user'] = '';
$all_options['realpage_api_password'] = '';
$all_options['realpage_api_siteid'] = '';
$all_options['realpage_api_pmcid'] = '';
$all_options['site_available_page_url'] = '';
$all_options['result_show_next_days'] = 0;
$all_options['result_show_prev_days'] = 0;
$all_options['calendar_upcoming_days'] = 120;

$all_options = wp_load_alloptions();
define('RRAC_RP_API_USER',isset($all_options['realpage_api_user'])?$all_options['realpage_api_user']:'');
define('RRAC_RP_API_PASSWORD',isset($all_options['realpage_api_password'])?$all_options['realpage_api_password']:'');
define('RRAC_RP_API_SITEID',isset($all_options['realpage_api_siteid'])?$all_options['realpage_api_siteid']:'');
define('RRAC_RP_API_PMCID',isset($all_options['realpage_api_pmcid'])?$all_options['realpage_api_pmcid']:'');
define('RRAC_SITE_AVAILABLE_PAGE',isset($all_options['site_available_page_url'])?$all_options['site_available_page_url']:'');
define('RESULT_SHOW_NEXT_DAYS',isset($all_options['result_show_next_days'])?$all_options['result_show_next_days']:'');
define('RESULT_SHOW_PREV_DAYS',isset($all_options['result_show_prev_days'])?$all_options['result_show_prev_days']:'');
define('CALENDAR_UPCOMING_DAYS',isset($all_options['calendar_upcoming_days'])?$all_options['calendar_upcoming_days']:'');

define('SCHEDULE_TOUR_ACTION_TYPE',isset($all_options['schedule_tour_action_type'])?$all_options['schedule_tour_action_type']:'');
define('SCHEDULE_TOUR_ACTION',isset($all_options['schedule_tour_action'])?$all_options['schedule_tour_action']:'');

define('CONTACT_ACTION_TYPE',isset($all_options['contact_action_type'])?$all_options['contact_action_type']:'');
define('CONTACT_ACTION',isset($all_options['contact_action'])?$all_options['contact_action']:'');

include_once('function.php');
include_once('shortcode.php');

register_activation_hook( __FILE__, 'rrac_install' ); //////////Activation Hook
register_uninstall_hook( __FILE__, 'rrac_unInstall' ); //////Uninstall Hook

// jQuery
// wp_enqueue_script('jquery');
// wp_enqueue_style('admin_css_bootstrap', plugins_url('/repli_realpage_apartment_sync/assets/css/bootstrap.min.css'), false, '3.3.6', 'all');
// wp_enqueue_script('admin_js_bootstrap', plugins_url('/repli_realpage_apartment_sync/assets/js/bootstrap.min.js'), false, '3.3.6', 'all');

// wp_enqueue_style('front_end_style', plugins_url('/repli_realpage_apartment_sync/assets/css/front_end_style.css'));

function all_includes()
	{
		wp_enqueue_script('jquery');

		wp_enqueue_style('admin_css_bootstrap', plugins_url('/repli_realpage_apartment_sync/assets/css/bootstrap.min.css'), false, '3.3.6', 'all');
		wp_enqueue_script('admin_js_bootstrap', plugins_url('/repli_realpage_apartment_sync/assets/js/bootstrap.min.js'), false, '3.3.6', 'all');
		wp_enqueue_style('front_end_style', plugins_url('/repli_realpage_apartment_sync/assets/css/front_end_style.css'));
		wp_enqueue_style('load_data_table_style', '//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css');
		wp_enqueue_style('load_ui_style', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
		//wp_enqueue_style('load_fancybox_style', '//cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css');

		//wp_enqueue_script('load_fancybox_script', '//cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js');
		/////Font Awesome

		wp_enqueue_style('load_font_awesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
	}
	add_action('init', 'all_includes');
	



function load_frontend_scripts(){
    wp_enqueue_script('front_end_script', plugins_url('/repli_realpage_apartment_sync/assets/js/front_end_script.js'));

    global $ajax_url;
    $dataToBePassed = array(
						    	'ajax_url' => $ajax_url ,
						    	'plugin_url' => plugins_url('/repli_realpage_apartment_sync') , 
						    	'default_move_in_date' => date('d F Y') , 
						    	'RRAC_SITE_AVAILABLE_PAGE' => RRAC_SITE_AVAILABLE_PAGE , 
						    	'RESULT_SHOW_NEXT_DAYS' => RESULT_SHOW_NEXT_DAYS,
						    	'CALENDAR_UPCOMING_DAYS' => CALENDAR_UPCOMING_DAYS,

						    );
	wp_localize_script( 'front_end_script', 'phpVar', $dataToBePassed );
}

// for front end
add_action('wp_enqueue_scripts', 'load_frontend_scripts');

///////////////////////
function load_data_table_script(){
    wp_enqueue_script('load_data_table', '//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js');
	
}
add_action('admin_enqueue_scripts', 'load_data_table_script');
//wp_enqueue_style('load_data_table_style', '//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css');

///////////////////////JQuery UI
function load_ui_script(){
    wp_enqueue_script('jquery-ui-datepicker');  ////wordpress default	
}
add_action('wp_enqueue_scripts', 'load_ui_script');
//wp_enqueue_style('load_ui_style', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');

///////////////////////JQuery FancyBox
function load_fancybox_script(){
    	
}
//add_action('wp_enqueue_scripts', 'load_fancybox_script');
//wp_enqueue_style('load_fancybox_style', '//cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css');

///////Font Awesome
//wp_enqueue_style('load_font_awesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');

if( !function_exists('get_plugin_data') ){
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}


include_once('dynamik_css.php');
?>