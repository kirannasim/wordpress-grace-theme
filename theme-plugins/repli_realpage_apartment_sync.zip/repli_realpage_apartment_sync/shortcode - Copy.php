<?php
function apartment_type_tab_view($atts) {
   extract(shortcode_atts(array(
      'type' => ''
   ), $atts));
   global $ajax_url;
   $str = '<div class="rracShortcodeSection"><img class="loadingImage" src="'.plugin_dir_url(__FILE__).'assets/images/loading.svg" width="100"/></div>';
   $str .= '<script>
                jQuery.ajax({
                    url:"'.$ajax_url.'",
                    data:"type='.$type.'&action=rrac_show_shortcode_data",
                    type:"POST",
                    cache:false,
                    success:function(data){
                      //alert(data);
                      jQuery(".rracShortcodeSection").html(data);
                    }
                });
            </script>';

   return $str;
}
add_shortcode('apartment_type_tab_view', 'apartment_type_tab_view');


add_action( 'wp_ajax_rrac_show_shortcode_data', 'rrac_show_shortcode_data' );
add_action( 'wp_ajax_nopriv_rrac_show_shortcode_data', 'rrac_show_shortcode_data' );
function rrac_show_shortcode_data()
{
  $type = $_POST['type'];
  ini_set('max_execution_time',90);
  global $wpdb;
  $table_name = $wpdb->prefix . 'rrac_floorplan_marketing_type';
   $sql_search_by_grp = "select *,substr(floorplan_code,1,1) as code from $table_name where status=1 group by code order by order_no";
   $search_res_by_grps = $wpdb->get_results($sql_search_by_grp);
   
   $rrac_tab_heading = get_option('rrac_tab_heading');
   $appTypeArray = array();
   if($rrac_tab_heading != "")
   {
      $appTypeArray = json_decode($rrac_tab_heading,true);
   }
   /////////highland View
  if($type == 'list_view_1'){ 
     $str = '<div class="rrac_tabSection rracHighland">';
     if(count($search_res_by_grps) > 0)
     {
          $str .= '<ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#rrac_all_apartment">All</a></li>';
            foreach($search_res_by_grps as $search_res_by_grp)
            {
                if(isset($appTypeArray[$search_res_by_grp->code])) 
                  $appTypeName = $appTypeArray[$search_res_by_grp->code];
                else
                  $appTypeName = $search_res_by_grp->code;
                $str .= '<li><a data-toggle="tab" href="#rrac_apartment_bed_'.$search_res_by_grp->code.'">'.$appTypeName.'</a></li>';
            }
            
          $str .= '</ul>';

          $sql_search = "select *,substr(floorplan_code,1,1) as code from $table_name where status=1 order by bedroom , bathroom";
          $search_res = $wpdb->get_results($sql_search);

          $str .= '<div class="tab-content">
              <div id="rrac_all_apartment" class="tab-pane fade in active">';
                foreach($search_res as $resKey=>$search_re)
                {
                   $str .= '<div class="col-md-12">
                              
                                <div class="col-md-3 col-sm-2 col-xs-12 rrac_appt_img">';
                                $image_path = $search_re->image == ""?plugin_dir_url(__FILE__).'assets/images/no_image.png':$search_re->image;
                                if($search_re->image == "")
                                {
                                    $str .= '<img src="'.$image_path.'" width="100" alt="" />';
                                }
                                else
                                {
                                    $str .= '<a href="'.$image_path.'" data-fancybox><img src="'.$image_path.'" width="100" alt="" /></a>';
                                }
                                
                                $str .= '</div>
                                <div class="col-md-6 col-sm-6 col-xs-12 rrac_appt_det">
                                  <div class="appname">'.$search_re->marketing_type.'</div>';

                                  if($search_re->tagline != "")
                                    $str .= '<div class="tagline">'.$search_re->tagline.'</div>';
                                  
                                  $str .= '
                                  <div class="appBedBath"><span>'.$search_re->bedroom.'</span> Bedroom | <span>'.$search_re->bathroom.'</span> Bathroom</div>
                                  <div class="appSize"><span>'.$search_re->size.'</span> Sq. Ft.</div>
                                  ';
                                  $total_available = get_available_unit_count($search_re->api_response_id );
                                  if($total_available['count'] > 0) 
                                  {
                                    $str .= '<div class="appMinRent">
                                                Starting At $<span>'.$total_available['unit_min_starting_price'].'</span>
                                            </div>';
                                  }
                                  if($total_available['count'] > 0) 
                                  {
                                      $str .= '<div class="totalAvailable">'.$total_available['count'].' Available Homes</div>';
                                  }

                                  $search_res[$resKey]->total_available = $total_available;

                                $str .= '</div>
                                <div class="col-md-3 col-sm-4 col-xs-12 rrac_appt_btn">';
                                if($total_available['count'] == 0)
                                  {
                                      $str .= '<a class="btn btn-primary" href="javascript:;" onclick="getContactFormSlide(\'direct_open\' , '.$search_re->api_response_id.')">Contact Us <i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                                  }
                                  else
                                  {
                                      $str .= '<a class="btn btn-primary" href="javascript:;" onclick="rrac_show_aprt_det('.$search_re->id.')">View Details <i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                                  }

                                  if(SCHEDULE_TOUR_ACTION_TYPE == 'html')
                                  {
                                    $btnaction = 'href="'.SCHEDULE_TOUR_ACTION.'"';
                                  }
                                  else
                                  {
                                    $btnaction = 'href="javascript:;" onclick="'.SCHEDULE_TOUR_ACTION.'"';
                                  }
                                  $str .= '<a class="btn btn-primary" '.$btnaction.'>​Schedule a Tour <i class="fa fa-angle-right" aria-hidden="true"></i></a>

                                </div> 
                              
                            </div>';
                    $str .= '';
                }  
            $str .= '</div>';
            foreach($search_res_by_grps as $search_res_by_grp)
            {
            $str .= '<div id="rrac_apartment_bed_'.$search_res_by_grp->code.'" class="tab-pane fade">';
                      foreach($search_res as $search_re)
                      {
                        if($search_res_by_grp->code == $search_re->code)
                        {
                            $str .= '<div class="col-md-12">
                              
                                <div class="col-md-3 col-sm-2 col-xs-12 rrac_appt_img">';
                                $image_path = $search_re->image == ""?plugin_dir_url(__FILE__).'assets/images/no_image.png':$search_re->image;
                                if($search_re->image == "")
                                {
                                    $str .= '<img src="'.$image_path.'" width="100" alt="" />';
                                }
                                else
                                {
                                    $str .= '<a href="'.$image_path.'" data-fancybox><img src="'.$image_path.'" width="100" alt="" /></a>';
                                }
                                
                                $str .= '</div>
                                <div class="col-md-6 col-sm-6 col-xs-12 rrac_appt_det">
                                  <div class="appname">'.$search_re->marketing_type.'</div>';

                                  if($search_re->tagline != "")
                                    $str .= '<div class="tagline">'.$search_re->tagline.'</div>';
                                  
                                  $str .= '
                                  <div class="appBedBath"><span>'.$search_re->bedroom.'</span> Bedroom | <span>'.$search_re->bathroom.'</span> Bathroom</div>
                                  <div class="appSize"><span>'.$search_re->size.'</span> Sq. Ft.</div>';
                                  $total_available = $search_re->total_available;
                                  if($total_available['count'] > 0) 
                                  {
                                    $str .= '<div class="appMinRent">
                                                Starting At $<span>'.$total_available['unit_min_starting_price'].'</span>
                                            </div>';
                                  }
                                  if($total_available['count'] > 0) 
                                  {
                                      $str .= '<div class="totalAvailable">'.$total_available['count'].' Available Homes</div>';
                                  }
                                  
                                $str .= '</div>
                                <div class="col-md-3 col-sm-4 col-xs-12 rrac_appt_btn">';
                                  if($total_available['count'] == 0)
                                  {
                                      $str .= '<a class="btn btn-primary" href="javascript:;" onclick="getContactFormSlide(\'direct_open\' , '.$search_re->api_response_id.')">Contact Us <i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                                  }
                                  else
                                  {
                                      $str .= '<a class="btn btn-primary" href="javascript:;" onclick="rrac_show_aprt_det('.$search_re->id.')">View Details <i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                                  }
                                  
                                  if(SCHEDULE_TOUR_ACTION_TYPE == 'html')
                                  {
                                    $btnaction = 'href="'.SCHEDULE_TOUR_ACTION.'"';
                                  }
                                  else
                                  {
                                    $btnaction = 'href="javascript:;" onclick="'.SCHEDULE_TOUR_ACTION.'"';
                                  }
                                  $str .= '<a class="btn btn-primary" '.$btnaction.'>​Schedule a Tour <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                </div> 
                              
                            </div>';
                            $str .= '';
                        }
                      }
            $str .= '</div>';
            }
            
          $str .= '</div>';
        
     }
     else
     {
        $str .= '<p>Apartment not available.</p>';
     }
     $str .= '</div>';
   }

  /////////Sentosa View
  if($type == 'list_view_2'){ 
     $str = '<div class="rrac_tabSection rracSentosa">';
     if(count($search_res_by_grps) > 0)
     {
          $countable =1;
          $str .= '<ul class="nav nav-tabs">
            ';
            foreach($search_res_by_grps as $search_res_by_grp)
            {
              $activeclass = "";
              if($countable == 1) $activeclass = "class=\"active\"";

              if(isset($appTypeArray[$search_res_by_grp->code])) 
                $appTypeName = $appTypeArray[$search_res_by_grp->code];
              else
                $appTypeName = $search_res_by_grp->code;

                $str .= '<li '.$activeclass.'><a data-toggle="tab" href="#rrac_apartment_bed_'.$search_res_by_grp->code.'">'.$appTypeName.'</a></li>';
              $countable++;
            }
            
          $str .= '</ul>';

          $sql_search = "select *,substr(floorplan_code,1,1) as code from $table_name where status=1 order by bedroom , bathroom";
          $search_res = $wpdb->get_results($sql_search);
        $countable =1;
          $str .= '<div class="tab-content">
              ';
            foreach($search_res_by_grps as $search_res_by_grp)
            {
              $activeclass = "";
              if($countable == 1) $activeclass = " in active";
              $str .= '<div id="rrac_apartment_bed_'.$search_res_by_grp->code.'" class="tab-pane fade '.$activeclass.'">';
                      foreach($search_res as $search_re)
                      {
                        if($search_res_by_grp->code == $search_re->code)
                        {
                             $str .= '<div class="col-md-12">
                              
                                <div class="col-md-6 col-sm-6 col-xs-12 rrac_appt_img">';
                                $image_path = $search_re->image == ""?plugin_dir_url(__FILE__).'assets/images/no_image.png':$search_re->image;
                                if($search_re->image == "")
                                {
                                    $str .= '<img src="'.$image_path.'" width="100" alt="" />';
                                }
                                else
                                {
                                    $str .= '<a href="'.$image_path.'" data-fancybox><img src="'.$image_path.'" width="100" alt="" /></a>';
                                }
                                
                                $str .= '</div>
                                <div class="col-md-6 col-sm-6 col-xs-12 rrac_appt_det">
                                  <div class="appname">'.$search_re->marketing_type.'</div>
                                  <div class="appBedBath appBed">Bedrooms <span>'.$search_re->bedroom.'</span></div>
                                  <div class="appBedBath appBath">Bathrooms <span>'.$search_re->bathroom.'</span></div>
                                  <div class="appSize">SQFT <span>'.$search_re->size.'</span></div>';
                                  if($search_re->deposit != "")
                                    $str .= '<div class="appDeposit">Deposit <span>'.$search_re->deposit.'</span></div>';
                                  if($search_re->term_range != "")
                                    $str .= '<div class="appTermRange">Available Lease Terms <span>'.$search_re->term_range.'</span></div>';
                                  
                                  $total_available = get_available_unit_count($search_re->api_response_id );
                                  if($total_available['count'] > 0) 
                                  {
                                    $str .= '<div class="appMinRent">
                                                Starting At <span>$'.$total_available['unit_min_starting_price'].'</span>
                                            </div>';
                                  }
                                  if($total_available['count'] > 0) 
                                  {
                                      $str .= '<div class="totalAvailable">'.$total_available['count'].' Available Homes</div>';
                                  }
                                
                                  $str .= '<div class=" rrac_appt_btn">';
                                  if($total_available['count'] == 0)
                                  {
                                      $str .= '<a class="btn btn-primary" href="javascript:;" onclick="getContactFormSlide(\'direct_open\' , '.$search_re->api_response_id.' )">Contact Us <i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                                  }
                                  else
                                  {
                                      $str .= '<a class="btn btn-primary" href="javascript:;" onclick="getUnitListByFloor('.$search_re->api_response_id.' , 2 )">View Pricing <i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                                  }
                                  

                                  if(SCHEDULE_TOUR_ACTION_TYPE == 'html')
                                  {
                                    $btnaction = 'href="'.SCHEDULE_TOUR_ACTION.'"';
                                  }
                                  else
                                  {
                                    $btnaction = 'href="javascript:;" onclick="'.SCHEDULE_TOUR_ACTION.'"';
                                  }
                                  $str .= '<a class="btn btn-primary" '.$btnaction.'>​Schedule a Tour <i class="fa fa-angle-right" aria-hidden="true"></i></a>

                                </div> 
                              </div>
                            </div>';
                    $str .= '';
                        }
                      }
            $str .= '</div>';
             $countable++;
            }
            
          $str .= '</div>';
        
     }
     else
     {
        $str .= '<p>Apartment not available.</p>';
     }
     $str .= '</div>
                  <script type="text/javascript">
                    jQuery(document).ready(function(){
                      jQuery(\'[data-fancybox]\').fancybox({});
                      ';
                      if($type == 'list_view_2'){ 
                        $str .= 'var template_type = 2;';
                      }

                    $str .= '});
                    
                  </script>
              ';
      if($type == 'list_view_2'){ 
        $str .= '<style>.appUnitListScreen .backem{display:none !important;}</style>';
      }
   }




  echo $str;
  exit;

}



/////////////////Pricing Shortcode/////////////
function rrac_min_unit_price($atts) {
   extract(shortcode_atts(array(
      'bedroom' => '',
      'floorplan_id' => ''
   ), $atts));
   $unit_lists = '';
   $BaseRentAmount = 0;
   if($bedroom != '')
   {
      $floorplan_id = "";
      $unit_lists = rrac_get_unit_list( $bedroom , $floorplan_id );
      
   }
   else if($floorplan_id != "")
   {
      $bedroom = "";
      $unit_lists = rrac_get_unit_list( $bedroom , $floorplan_id );
   }
   else
   {
      $unit_lists = rrac_get_unit_list( );
   }
   //echo "<pre>"; print_r($unit_lists); die;
   if(isset($unit_lists->ListResponse->ListResult->UnitObject))
   {
    $count = 1;
      foreach($unit_lists->ListResponse->ListResult->UnitObject as $res)
      {
        if($count == 1) {
          $BaseRentAmount = floatval($res->BaseRentAmount);
        }
        else if(floatval($BaseRentAmount) > floatval($res->BaseRentAmount) )
        {
            $BaseRentAmount = floatval($res->BaseRentAmount);
        }
        //echo floatval($BaseRentAmount).'<br>'; 
        $count++;
      }
      $BaseRentAmount = 'Starting at $'.$BaseRentAmount;
   }
   else
   {
      $BaseRentAmount = 'Limited Availability';
   }
   return $BaseRentAmount;
 }
 add_shortcode('rrac_min_unit_price', 'rrac_min_unit_price');
?>
