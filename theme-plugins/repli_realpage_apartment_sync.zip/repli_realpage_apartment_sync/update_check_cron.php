<?php 
include_once('../../../wp-load.php');
include_once('repli_realpage_apartment_sync.php');
include_once('function.php');

$current_version = RRAC_PLUGIN_VERSION;
$plugin_store_url = RRAC_PLUGIN_URL;
$plugin_store_user_name = 'userName';
$plugin_store_user_pass = 'userPass';
$plugin_store_id = STORE_PLUGIN_ID;
///////////CURL
$ch = curl_init();
$fields = array( 'user'=>$plugin_store_user_name, 'pass'=>$plugin_store_user_pass , 'plugin_store_id' => $plugin_store_id, 'action'=>'get_latest_version_info');
$postvars = '';
foreach($fields as $key=>$value) {
  $postvars .= $key . "=" . $value . "&";
}
$url = $plugin_store_url.'/api_request.php';
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_POST, 1);                //0 for a get request
curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
curl_setopt($ch,CURLOPT_TIMEOUT, 20);
$response = curl_exec($ch);
curl_close ($ch);

if($response)
{
	$res = json_decode($response,true);
	if(isset($res['status']) && $res['status'] == 200 )
	{
		$latest_ver = $res['result']['version'];
        if($latest_ver > $current_version){
        	update_option('rrac_update_status',1);
        }
        else
        {
        	update_option('rrac_update_status',0);
        }
	}
	else
	{
		update_option('rrac_update_status',0);
	}
}
else
{
	update_option('rrac_update_status',0);
}

?>