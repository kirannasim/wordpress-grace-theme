<div class="col-md-12 rrac_app_tab_heading_page rrac_admin_page">
	
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Check Update</h3>
	<hr/>
	

	<div class="col-md-12">
		<h4>Check Update:</h4>
		<p class="update_status_message"></p>
	</div>
</div>
<?php 
global $ajax_url;
update_option('rrac_version',RRAC_PLUGIN_VERSION);
?>

  
<script>
var ajaxurl = '<?php echo $ajax_url;?>';
jQuery(document).ready(function(){
	jQuery('.rrac_admin_overlay').show();
	jQuery.ajax({
		url:ajaxurl,
		data:'action=rrac_check_for_update',
		type:'POST',
		cache:false,
		success:function(data){
			console.log(data);
			jQuery('.update_status_message').html(data);
			jQuery('.rrac_admin_overlay').hide();
									
		}
	});
	
	jQuery('.rrac_admin_page').css('min-height',jQuery(document).height()+'px');
});

function get_updated_file(filepath)
{
	jQuery('.rrac_admin_overlay').show();
	
	jQuery.ajax({
		url:ajaxurl,
		data:'filepath='+filepath+'&action=rrac_update_version_file_download',
		type:'POST',
		cache:false,
		success:function(data){
			console.log(data);
			//jQuery('.update_status_message').html(data);
			if(data == 'ok')
			{
				jQuery('.update_status_message').html('Plugin Updated successfully.');
			}
			jQuery('.rrac_admin_overlay').hide();
			setTimeout(function(){
				window.location.reload();
			},3000);								
		}
	});
}
		
</script>
<style type="text/css">
	.update_status_message{width: auto; margin: 10% auto; text-align: center; font-size: 24px; color: #e31792; }
	.update_status_message a{ padding: 3px; background: #444; color: #fff; margin-left: 5px; border-radius: 5px; }
</style>
<div class="rrac_admin_overlay" >
	<div class="content_area">Checking.....</div>
</div>