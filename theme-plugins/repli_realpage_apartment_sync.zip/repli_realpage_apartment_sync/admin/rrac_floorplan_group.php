<?php
global $wpdb;
$table_group = $wpdb->prefix . 'rrac_floorplan_group';

$sql_search = "select * from $table_group where 1";
$search_res = $wpdb->get_results($sql_search);
?>
<div class="col-md-12 rrac_group_list_page rrac_admin_page">
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Floorplan Group List</h3>
	<hr/>
	<div class="alert alert-success" style="display: none;">
  		<button type="button" class="close">x</button>
	  	<strong>Success!</strong> Credential saved successfully.
	</div>
	<div class="col-md-12">
		<div class="col-md-6 col-xs-12"><h4>Site Lists:</h4></div>
		<div class="col-md-6 col-xs-12 text-right">
			<a class="btn btn-success addlocation" href="<?php echo admin_url('admin.php?page=rrac_floorplan_group_edit') ?>" >Add Group</a>
		</div>
		<div class="col-md-12">&nbsp;</div>
		<form action="javascript:;" method="POST" id="siteListFrm">
			<div class="appListingSection">
			<table class="table" id="rrac_siteList">
			    <thead>
					<tr>
						<!-- <th><input type="checkbox" id="selectall" class="css-checkbox" name="selectall"/></th> -->
						<th>ID</th>
						<th>Group Name</th>
						<th>Bedroom</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
			    </thead>
			    <tbody>
					<?php
					foreach($search_res as $search_re) {
					?>
					<tr>
						<!-- <td><input type="checkbox" class="checkboxall" name="deleteItem[]" value="<?php echo $search_re->id;?>"/></td> -->
						<td><?php echo $search_re->id;?></td>
						<td><?php echo $search_re->group_name;?></td>
						<td><?php echo $search_re->bedroom;?></td>
						<td><?php echo $search_re->status==1?'Active':'Inactive';?></td>
						<td>
							<a class="btn btn-xs btn-success" href="<?php echo admin_url('admin.php?page=floor_plan_type&group_id='.$search_re->id) ?>">View Floor Plan</a>
							<a class="btn btn-xs btn-primary" href="<?php echo admin_url('admin.php?page=rrac_floorplan_group_edit&id='.$search_re->id) ?>">Edit</a>
							<a class="btn btn-xs btn-danger" onclick="delete_this('<?php echo $search_re->id ?>');" href="javascript:;">Delete</a>
						</td>
					</tr>
					<?php 
					}
					?>
				</tbody>
			</table>
			</div>
		</form>
	</div>
</div>
<?php global $ajax_url;?>
<script>
	var ajaxurl = '<?php echo $ajax_url;?>';
	var plugin_url = '<?php echo plugins_url('/repli_realpage_apartment_sync');?>';
	jQuery(document).ready(function(){
		var append_string='<div class="rrac_loader_container"><div class="img_section"><img src="'+plugin_url+'/assets/images/loading.gif" width="100%" alt="" /></div></div>';
		jQuery('body').prepend(append_string);
		////////////////////////
		
		jQuery('.alert-success .close').on('click',function(){
	        jQuery(this).closest('.alert').slideUp();
	   });
	    /////////////Data Table
		jQuery('#rrac_siteList').DataTable({
			'order':[],
            'columnDefs': [{
                "targets": [-1,0],
                "orderable": false
            }]
		});
		/////////////delete selected items
		jQuery('#delSelected').on('click', function(){
			var flag = false;
			jQuery('.checkboxall').each(function(){
	            if(this.checked){
	            	flag = true;
	            	return;
	            }
	         });
			if(flag)
			{
				if(confirm('Are you sure to delete selected items?'))
				{
					var data =jQuery('#siteListFrm').serialize();
					jQuery.ajax({
						url:ajaxurl,
						data:data+'&action=rrac_delSelectedSite',
						type:'POST',
						cache:false,
						success:function(data){
							alert('Items deleted successfully.');
							window.location.reload();						
						}
					});
				}
				
			}
			else
			{
				alert('Please select atleast one item to delete.');
			}
			
			return false;
		});
			
	});
	function delete_this(idd)
	{
		if(confirm('Are you sure to delete this item?'))
		{
			jQuery.ajax({
				url:ajaxurl,
				data:'idd='+idd+'&action=rrac_delGroup',
				type:'POST',
				cache:false,
				success:function(data){
					alert('Item deleted successfully.');
					window.location.reload();						
				}
			})
			return false;
		}
	}
	j
		
</script>
