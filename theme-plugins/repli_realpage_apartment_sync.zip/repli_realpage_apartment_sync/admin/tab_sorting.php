<?php
global $wpdb;
   $table_name = $wpdb->prefix . 'rrac_floorplan_group';
   $sql_search_by_grp = "select * from $table_name where status=1 order by order_no asc";
   $search_res_by_grps = $wpdb->get_results($sql_search_by_grp);

?>
<div class="col-md-12 rrac_app_edit_page rrac_admin_page">
	<h3><?php echo RRAC_PLUGIN_NAME;?> - Tab Sorting</h3>
	<hr/>
	<div class="alert alert-success" style="display: none;">
  		<button type="button" class="close">x</button>
	  	<strong>Success!</strong> Credential saved successfully.
	</div>

	<div class="col-md-12">
		<h4>Tab Heading sort:</h4>
		
		<ul id="sortable">
  
		<?php
		$count = 0; 
		foreach($search_res_by_grps as $search_res_by_grp)
        {
            $appTypeName = $search_res_by_grp->group_name;
          ?>
            <li id="<?php echo $search_res_by_grp->id;?>" ><?php echo $appTypeName;?></li>
          <?php
          $count++;
        }
        
        ?>
		</ul>
		<?php
		if($count == 0)
		{
			echo "No data available.";
		}
		?>
	</div>
</div>
<?php global $ajax_url;?>

  <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
	var ajaxurl = '<?php echo $ajax_url;?>';
	jQuery(document).ready(function(){
		

		jQuery('.alert-success .close').on('click',function(){
	        jQuery(this).closest('.alert').slideUp();
	   });
		

	    jQuery( "#sortable" ).sortable({
	    	placeholder: "ui-state-highlight",
	      	axis: 'y',
    		stop: function (event, ui) {
    		jQuery('.rrac_admin_overlay').show();
            var Order = jQuery(this).sortable('toArray');
            console.log(Order);
            	jQuery.ajax({
					url:ajaxurl,
					data:'orderarray='+Order+'&action=rrac_tab_ordering',
					type:'POST',
					cache:false,
					success:function(data){
						console.log(data);
						if(data == 1)
						{
							alert('Updated successfully');
							jQuery('.rrac_admin_overlay').hide();
						}						
					}
				});
            }
	    });
		jQuery( "#sortable" ).disableSelection();
		jQuery('.rrac_admin_page').css('min-height',jQuery(document).height()+'px');
	});


		
</script>
<div class="rrac_admin_overlay" >
	<div class="content_area">Processing.....</div>
</div>
